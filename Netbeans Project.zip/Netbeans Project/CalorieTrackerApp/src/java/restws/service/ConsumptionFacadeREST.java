/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restws.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import restws.Consumption;
import java.text.SimpleDateFormat;  
import java.util.Date;  
import restws.JSONCreator;



/**
 *
 * @author Pranali
 */
@Stateless
@Path("restws.consumption")
public class ConsumptionFacadeREST extends AbstractFacade<Consumption> {

    @PersistenceContext(unitName = "CalorieTrackerAppPU")
    private EntityManager em;

    public ConsumptionFacadeREST() {
        super(Consumption.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Consumption entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Consumption entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Consumption find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Consumption> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Consumption> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    //@Produces(MediaType.TEXT_PLAIN)
    @Produces({"application/json"})
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @GET
    @Path("findByDate/{date}")
    @Produces({"application/json"})
    public List<Consumption> findByDate(@PathParam("date") String date) throws Exception{
        Query query = em.createNamedQuery("Consumption.findByDate");
        Date dateParsed = new SimpleDateFormat("yyyy-MM-dd").parse(date);         
        query.setParameter("date", dateParsed);
        return query.getResultList();
    }
    
    @GET
    @Path("findByQtyorserving/{qtyorserving}")
    @Produces({"application/json"})
    public List<Consumption> findByQtyorserving(@PathParam("qtyorserving") Double qtyorserving) {
        Query query = em.createNamedQuery("Consumption.findByQtyorserving");
        query.setParameter("qtyorserving", qtyorserving);
        return query.getResultList();
    }
    @GET
    @Path("findByUserid/{userid}")
    @Produces({"application/json"})
    public List<Consumption> findByUserid(@PathParam("userid") Integer userid) {
        Query query = em.createNamedQuery("Consumption.findByUserid");
        query.setParameter("userid", userid);
        return query.getResultList();
    }
    
    @GET
    @Path("findByFoodid/{foodid}")
    @Produces({"application/json"})
    public List<Consumption> findByFoodid(@PathParam("foodid") Integer foodid) {
        Query query = em.createNamedQuery("Consumption.findByFoodid");
        query.setParameter("foodid", foodid);
        return query.getResultList();
    }
    
    @GET
    @Path("findByNameQtyorserving/{name}/{qtyorserving}")
    @Produces({"application/json"})
    public List<Consumption> findByNameQtyorserving(@PathParam("name") String name, @PathParam("qtyorserving") Double qtyorserving) {
        Query query = em.createNamedQuery("Consumption.findByNameQtyorserving");
        query.setParameter("name", name);
        query.setParameter("qtyorserving", qtyorserving);
        return query.getResultList();
    }


    
    @GET
    @Path("calculateTotalCaloriesConsumedPerDay/{userid}/{date}")
    @Produces("text/plain")
    public String calculateTotalCaloriesConsumedPerDay(@PathParam("userid") Integer userid, @PathParam("date") String date) throws Exception {
        TypedQuery<Consumption> query = em.createQuery("SELECT c FROM Consumption c WHERE c.userid.userid = :userid and c.date = :date", Consumption.class);
        Date parsedDate = new SimpleDateFormat("yyyy-MM-dd").parse(date);
        query.setParameter("userid",userid);
        query.setParameter("date",parsedDate);
        Set<Integer> setOfFoods = new HashSet<Integer>();
        Double caloriesPerFood = 0.0;
        Double totalCaloriesPerDay = 0.0;
        Double caloriesPerServing = 0.0;
        List<Consumption> listOfConsumption = query.getResultList();
        for (int i = 0; i < listOfConsumption.size(); i++)
            setOfFoods.add(listOfConsumption.get(i).getFoodid().getFoodid());
        List<Integer> listOfFoods = new ArrayList<Integer>(setOfFoods); 
        for (int i = 0; i < listOfFoods.size(); i++)
        {
            caloriesPerFood = 0.0;
              for (int j = 0; j < listOfConsumption.size(); j++) 
              {
                  if (listOfConsumption.get(j).getFoodid().getFoodid() == listOfFoods.get(i))
                  {
                    caloriesPerServing = Double.parseDouble(listOfConsumption.get(j).getQtyorserving().toString()) * 
                            Double.parseDouble(listOfConsumption.get(j).getFoodid().getCalorieamount().toString()) / 
                            Double.parseDouble(listOfConsumption.get(j).getFoodid().getServingamount().toString());
                    caloriesPerFood = caloriesPerFood + caloriesPerServing;
                  }
              }
               totalCaloriesPerDay = totalCaloriesPerDay + caloriesPerFood;
        }
      
        return totalCaloriesPerDay.toString();
        
    }

}
