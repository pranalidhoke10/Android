/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restws.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import restws.JSONCreator;
import restws.Report;

/**
 *
 * @author Pranali
 */
@Stateless
@Path("restws.report")
public class ReportFacadeREST extends AbstractFacade<Report> {

    @PersistenceContext(unitName = "CalorieTrackerAppPU")
    private EntityManager em;

    public ReportFacadeREST() {
        super(Report.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Report entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Report entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Report find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Report> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Report> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    //@Produces(MediaType.TEXT_PLAIN)
    @Produces({"application/json"})
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @GET
    @Path("findByReportid/{reportid}")
    @Produces({"application/json"})
    public List<Report> findByReportid(@PathParam("reportid") Integer reportid) {
        Query query = em.createNamedQuery("Report.findByReportid");
        query.setParameter("reportid",reportid);
        return query.getResultList();
    }
    
    @GET
    @Path("findByDate/{date}")
    @Produces({"application/json"})
    public List<Report> findByDate(@PathParam("date") String date) throws Exception{
        Query query = em.createNamedQuery("Report.findByDate");
        Date dateParsed = new Date();      
        dateParsed=new SimpleDateFormat("yyyy-MM-dd").parse(date);         
        query.setParameter("date", dateParsed);
        return query.getResultList();
    }
    
    @GET
    @Path("findByTotalcalconsumed/{totalcalconsumed}")
    @Produces({"application/json"})
    public List<Report> findByTotalcalconsumed(@PathParam("totalcalconsumed") Double totalcalconsumed) {
        Query query = em.createNamedQuery("Report.findByTotalcalconsumed");
        query.setParameter("totalcalconsumed", totalcalconsumed);
        return query.getResultList();
    }
    
    @GET
    @Path("findByTotalcalburned/{totalcalburned}")
    @Produces({"application/json"})
    public List<Report> findByTotalcalburned(@PathParam("totalcalburned") Double totalcalburned) {
        Query query = em.createNamedQuery("Report.findByTotalcalburned");
        query.setParameter("totalcalburned", totalcalburned);
        return query.getResultList();
    }
    
    @GET
    @Path("findByTotalsteps/{totalsteps}")
    @Produces({"application/json"})
    public List<Report> findByTotalsteps(@PathParam("totalsteps") Integer totalsteps) {
        Query query = em.createNamedQuery("Report.findByTotalsteps");
        query.setParameter("totalsteps", totalsteps);
        return query.getResultList();
    }
    
    @GET
    @Path("findBySetcalgoal/{setcalgoal}")
    @Produces({"application/json"})
    public List<Report> findBySetcalgoal(@PathParam("setcalgoal") Double setcalgoal) {
        Query query = em.createNamedQuery("Report.findBySetcalgoal");
        query.setParameter("setcalgoal", setcalgoal);
        return query.getResultList();
    }
    
    @GET
    @Path("findByUserid/{userid}")
    @Produces({"application/json"})
    public List<Report> findByUserid(@PathParam("userid") Integer userid) {
        Query query = em.createNamedQuery("Report.findByUserid");
        query.setParameter("userid", userid);
        return query.getResultList();
    }
    
    @GET
    @Path("calculateReportValues/{userid}/{date}")
    @Produces({"application/json"})
    public List<JSONCreator> calculateReportValues(@PathParam("userid") Integer userid,@PathParam("date") String date) throws Exception{
        TypedQuery<Report> query = em.createQuery("SELECT r FROM Report r WHERE r.userid.userid = :userid and r.date = :date", Report.class);
        Date dateParsed = new SimpleDateFormat("yyyy-MM-dd").parse(date);
        query.setParameter("userid",userid);
        query.setParameter("date", dateParsed);
        if (query != null && query.getResultList().size() > 0){
            Double totalCalConsumed = Double.parseDouble(query.getSingleResult().getTotalcalconsumed().toString());
            Double setCalGoal = Double.parseDouble(query.getSingleResult().getSetcalgoal().toString());
            Double totalCalBurned = Double.parseDouble(query.getSingleResult().getTotalcalburned().toString());
            Double calGoal = Double.parseDouble (query.getSingleResult().getSetcalgoal().toString());
            Double remainingCalories;
            if (totalCalBurned >= setCalGoal)
                remainingCalories = 0.0;
            else
                remainingCalories = setCalGoal - totalCalBurned;
            List<JSONCreator> listOfNamesValues = new ArrayList<JSONCreator>();
            JSONCreator jcConsumed = new JSONCreator("calConsumed",totalCalConsumed.toString());
            JSONCreator jcBurned = new JSONCreator("calBurned",totalCalBurned.toString());
            JSONCreator jcRemaining = new JSONCreator("calRemaining",remainingCalories.toString());
            JSONCreator jcCalGoal = new JSONCreator("calGoal",calGoal.toString());

            listOfNamesValues.add(jcConsumed);
            listOfNamesValues.add(jcBurned);
            listOfNamesValues.add(jcRemaining);
            listOfNamesValues.add(jcCalGoal);
           return listOfNamesValues;
        }
        return null;
    }
    
    @GET
    @Path("calculateReportValuesForDuration/{userid}/{startdate}/{enddate}")
    @Produces({"application/json"})
    public List<JSONCreator> calculateReportValuesForDuration(@PathParam("userid") Integer userid,@PathParam("startdate") String startdate,@PathParam("enddate") String enddate) throws Exception{
        TypedQuery<Report> query = em.createQuery("SELECT r FROM Report r WHERE r.userid.userid = :userid and r.date >= :startdate and r.date <= :enddate", Report.class);
        Date startDateParsed=new SimpleDateFormat("yyyy-MM-dd").parse(startdate); 
        Date endDateParsed=new SimpleDateFormat("yyyy-MM-dd").parse(enddate); 
        query.setParameter("userid",userid);
        query.setParameter("startdate", startDateParsed);
        query.setParameter("enddate", endDateParsed);
        Double totalCalConsumed = 0.0;
        Double totalStepsTaken = 0.0;
        Double totalCalBurned = 0.0;
        List<Report> listOfReports = query.getResultList();
        for (int i = 0; i < listOfReports.size(); i++)
        {
            totalCalConsumed = totalCalConsumed + Double.parseDouble(listOfReports.get(i).getTotalcalconsumed().toString());
            totalCalBurned = totalCalBurned + Double.parseDouble(listOfReports.get(i).getTotalcalburned().toString());
            totalStepsTaken = totalStepsTaken + Double.parseDouble(listOfReports.get(i).getTotalsteps().toString());
        }
        List<JSONCreator> listOfNamesValues = new ArrayList<JSONCreator>();
        JSONCreator jcBurned = new JSONCreator("total calories burned",totalCalBurned.toString());
        JSONCreator jcConsumed = new JSONCreator("total calories consumed",totalCalConsumed.toString());
        JSONCreator jcSteps = new JSONCreator("total steps taken",totalStepsTaken.toString());
        listOfNamesValues.add(jcBurned);
        listOfNamesValues.add(jcConsumed);
        listOfNamesValues.add(jcSteps);
        
       return listOfNamesValues;
    }
    
@GET
    @Path("reportValuesForDuration/{userid}/{startdate}/{enddate}")
    @Produces({"application/json"})
    public List<Report> reportValuesForDuration(@PathParam("userid") Integer userid,@PathParam("startdate") String startdate,@PathParam("enddate") String enddate) throws Exception{
        TypedQuery<Report> query = em.createQuery("SELECT r FROM Report r WHERE r.userid.userid = :userid and r.date >= :startdate and r.date <= :enddate", Report.class);
        Date startDateParsed=new SimpleDateFormat("yyyy-MM-dd").parse(startdate); 
        Date endDateParsed=new SimpleDateFormat("yyyy-MM-dd").parse(enddate); 
        query.setParameter("userid",userid);
        query.setParameter("startdate", startDateParsed);
        query.setParameter("enddate", endDateParsed);
        return query.getResultList();
    
    }

    @GET
    @Path("findByUseridDate/{userid}/{date}")
    @Produces({"application/json"})
    public List<Report> findByUseridDate(@PathParam("userid") Integer userid,@PathParam("date") String date) throws Exception{
        TypedQuery<Report> query = em.createQuery("SELECT r FROM Report r WHERE r.userid.userid = :userid and r.date = :date", Report.class);
        Date dateParsed = new SimpleDateFormat("yyyy-MM-dd").parse(date);
        query.setParameter("userid",userid);
        query.setParameter("date", dateParsed);
        return query.getResultList();
        
    }

    
}
