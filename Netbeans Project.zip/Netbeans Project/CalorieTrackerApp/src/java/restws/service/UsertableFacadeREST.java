/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restws.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import restws.Usertable;

/**
 *
 * @author Pranali
 */
@Stateless
@Path("restws.usertable")
public class UsertableFacadeREST extends AbstractFacade<Usertable> {

    @PersistenceContext(unitName = "CalorieTrackerAppPU")
    private EntityManager em;

    public UsertableFacadeREST() {
        super(Usertable.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Usertable entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Usertable entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Usertable find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Usertable> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Usertable> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
   // @Produces(MediaType.TEXT_PLAIN)
    @Produces({"application/json"})
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @GET
    @Path("findByUserid/{userid}")
    @Produces({"application/json"})
    public List<Usertable> findByUserid(@PathParam("userid") Integer userid) {
        Query query = em.createNamedQuery("Usertable.findByUserid");
        query.setParameter("userid",userid);
        return query.getResultList();
    }
    
    @GET
    @Path("findByName/{name}")
    @Produces({"application/json"})
    public List<Usertable> findByName(@PathParam("name") String name) {
        Query query = em.createNamedQuery("Usertable.findByName");
        query.setParameter("name",name);
        return query.getResultList();
    }
    
    @GET
    @Path("findBySurname/{surname}")
    @Produces({"application/json"})
    public List<Usertable> findBySurname(@PathParam("surname") String surname) {
        Query query = em.createNamedQuery("Usertable.findBySurname");
        query.setParameter("surname",surname);
        return query.getResultList();
    }
    
    @GET
    @Path("findByEmail/{email}")
    @Produces({"application/json"})
    public List<Usertable> findByEmail(@PathParam("email") String email) {
        Query query = em.createNamedQuery("Usertable.findByEmail");
        query.setParameter("email",email);
        return query.getResultList();
    }
    
    @GET
    @Path("findByDateofbirth/{dateofbirth}")
    @Produces({"application/json"})
    public List<Usertable> findByDateofbirth(@PathParam("dateofbirth") String dateofbirth) throws Exception {
        Query query = em.createNamedQuery("Usertable.findByDateofbirth");
        Date dateParsed = new SimpleDateFormat("yyyy-MM-dd").parse(dateofbirth);  
        query.setParameter("dateofbirth",dateParsed);
        return query.getResultList();
    }
    
    @GET
    @Path("findByHeight/{height}")
    @Produces({"application/json"})
    public List<Usertable> findByHeight(@PathParam("height") Double height) {
        Query query = em.createNamedQuery("Usertable.findByHeight");       
        query.setParameter("height",height);
        return query.getResultList();
    }
    
    @GET
    @Path("findByWeight/{weight}")
    @Produces({"application/json"})
    public List<Usertable> findByWeight(@PathParam("weight") Double weight) {
        Query query = em.createNamedQuery("Usertable.findByWeight");       
        query.setParameter("weight",weight);
        return query.getResultList();
    }
    
    @GET
    @Path("findByAddress/{address}")
    @Produces({"application/json"})
    public List<Usertable> findByAddress(@PathParam("address") String address) {
        Query query = em.createNamedQuery("Usertable.findByAddress");       
        query.setParameter("address",address);
        return query.getResultList();
    }
    
    @GET
    @Path("findByActivitylevel/{activitylevel}")
    @Produces({"application/json"})
    public List<Usertable> findByActivitylevel(@PathParam("activitylevel") Integer activitylevel) {
        Query query = em.createNamedQuery("Usertable.findByActivitylevel");       
        query.setParameter("activitylevel",activitylevel);
        return query.getResultList();
    }
    
    @GET
    @Path("findByGender/{gender}")
    @Produces({"application/json"})
    public List<Usertable> findByGender(@PathParam("gender") String gender) {
        Query query = em.createNamedQuery("Usertable.findByGender");       
        query.setParameter("gender",gender.charAt(0));
        return query.getResultList();
    }
    
    @GET
    @Path("findByPostcode/{postcode}")
    @Produces({"application/json"})
    public List<Usertable> findByPostcode(@PathParam("postcode") Integer postcode) {
        Query query = em.createNamedQuery("Usertable.findByPostcode");       
        query.setParameter("postcode",postcode);
        return query.getResultList();
    }
    
    @GET
    @Path("findByStepspermile/{stepspermile}")
    @Produces({"application/json"})
    public List<Usertable> findByStepspermile(@PathParam("stepspermile") Integer stepspermile) {
        Query query = em.createNamedQuery("Usertable.findByStepspermile");       
        query.setParameter("stepspermile",stepspermile);
        return query.getResultList();
    }
    
    @GET
    @Path("findByActivitylevelStepspermile/{activitylevel}/{stepspermile}")
    @Produces({"application/json"})
    public List<Usertable> findByActivitylevelStepspermile(@PathParam("activitylevel") Integer activitylevel, @PathParam("stepspermile") Integer stepspermile) {
        TypedQuery<Usertable> query = em.createQuery("SELECT u FROM Usertable u WHERE u.activitylevel = :activitylevel and u.stepspermile = :stepspermile", Usertable.class);
        query.setParameter("activitylevel",activitylevel);
        query.setParameter("stepspermile",stepspermile);   
        return query.getResultList();
    }
    
    @GET
    @Path("calculateCaloriesBurnedPerStep/{userid}")
    @Produces({"application/json"})
    public String calculateCaloriesBurnedPerStep(@PathParam("userid") Integer userid) {
       
        TypedQuery<Usertable> query = em.createQuery("SELECT u FROM Usertable u WHERE u.userid = :userid", Usertable.class);
        query.setParameter("userid",userid);
        Double calBurnedPerMile = 0.0;
        Double calBurnedPerStep = 0.0;
        if (query.getResultList().size() > 0)
        {
            calBurnedPerMile = Double.parseDouble(query.getSingleResult().getWeight().toString()) * 2.205 * 0.49;
            calBurnedPerStep = calBurnedPerMile / Double.parseDouble(query.getSingleResult().getStepspermile().toString());
        }
   
        return calBurnedPerStep.toString();
    }
    
    @GET
    @Path("calculateBMRAmt/{userid}")
    @Produces({"application/json"})
    public String calculateBMRAmt(@PathParam("userid") Integer userid) {
        TypedQuery<Usertable> query = em.createQuery("SELECT u FROM Usertable u WHERE u.userid = :userid", Usertable.class);
        query.setParameter("userid",userid);
        DateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        Date dob = query.getSingleResult().getDateofbirth();
        Date currentDate = new Date();
        int age = (Integer.parseInt(formatter.format(currentDate)) - Integer.parseInt(formatter.format(dob)))/10000;
        Double bmr = 0.0;
        Double weight = Double.parseDouble(query.getSingleResult().getWeight().toString());
        Double height = Double.parseDouble(query.getSingleResult().getHeight().toString());
        String gender = query.getSingleResult().getGender().toString();
        if (gender.equals("M") || gender.equals("m"))
            bmr = 13.75 * weight + 5.003 * height - 6.755 * age + 66.5;
        else if (gender.equals("F") || gender.equals("f"))
            bmr = 9.563 * weight + 1.85 * height - 4.676 * age + 655.1;
        return bmr.toString();
    }
   
    @GET
    @Path("calculateCalBurnedAtRest/{userid}")
    @Produces({"application/json"})
    public String calculateCalBurnedAtRest(@PathParam("userid") Integer userid) {
        TypedQuery<Usertable> query = em.createQuery("SELECT u FROM Usertable u WHERE u.userid = :userid", Usertable.class);
        query.setParameter("userid",userid);
        Double bmr = Double.parseDouble(calculateBMRAmt(userid));
        Double calBurnedAtRest = 0.0;
        int activityLevel = query.getSingleResult().getActivitylevel();
        if (activityLevel == 1)
            calBurnedAtRest = bmr * 1.2;
        else if (activityLevel == 2)
            calBurnedAtRest = bmr * 1.375;
        else if (activityLevel == 3)
            calBurnedAtRest = bmr * 1.55;
        else if (activityLevel == 4)
            calBurnedAtRest = bmr * 1.725;
        else if (activityLevel == 5)
            calBurnedAtRest = bmr * 1.99;
        return calBurnedAtRest.toString();
        }
       
    
  
    
}
